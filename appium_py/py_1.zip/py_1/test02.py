import pytest


def setup(a, b):
    c = a + b
    print(c)


setup(11111111111111, 1)

if __name__ == '__main__':
    pytest.main()
