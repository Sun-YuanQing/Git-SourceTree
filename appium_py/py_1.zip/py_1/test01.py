import pytest
from appium import webdriver
# from appium.webdriver import WebElement
from appium.webdriver.common.appiumby import AppiumBy
# from selenium.webdriver.common.by import By
from appium.webdriver.extensions.android.nativekey import AndroidKey


class TestDow():
    def setup(self):
        desired_caps = {"platformName": "Android", "deviceName": "LMV500N01894ed0", "noReset": True}
        # 连接Appium Server，初始化自动化环境;
        self.driver = webdriver.Remote('http://localhost:4723/wd/hub', desired_caps)
        print('**** 【初始化自动化环境】')
        # 设置缺省等待时间
        self.driver.implicitly_wait(5)

    def test_search(self):
        self.setup()
        print('**** 【test_search】')
        el1 = self.isdom();
        if  el1:
            print('**** you')
            self.test_send_keys()
        else:
            print('****m you')
            el2 = self.driver.find_element(AppiumBy.ID, "tv.danmaku.bili:id/expand_search")
            el2.click()
            el3 = self.driver.find_element(AppiumBy.ACCESSIBILITY_ID, "搜索查询")
            el3.click()
            el3.send_keys('孙元清 测试案例')
            print(el3.text)
            self.driver.press_keycode(AndroidKey.ENTER)
            self.test_send_keys()


    def teardown(self):
        print('【testdown】')
        self.driver.quit()

    def isdom(self):
        try:
            self.driver.find_element(AppiumBy.ID, "tv.danmaku.bili:id/ogv_layout")
        except Exception as e:
            return False
        else:
            return True

    def test_send_keys(self):
        # 选择（定位）所有视频标题 tv.danmaku.bili:id/title
        self.driver.implicitly_wait(6)
        # tv.danmaku.bili:id/recycler_view  androidx.recyclerview.widget.RecyclerView
        el4 = self.driver.find_elements(AppiumBy.XPATH,
                                        "//*[@resource-id='tv.danmaku.bili:id/title' and @class='android.widget.TextView']")
        # el4 = self.driver.find_elements(AppiumBy.RESOURCE_ID, 'android.widget.TextView')
        # print(el4)
        # print(el4)
        # elements = self.driver.find_elements_by_class_name("android.widget.TextView")
        # input(elements)
        # elements1 = elements[1].find_elements_by_class_name("android.view.ViewGroup")
        # input(elements1)s

        count = 0;
        for ele1 in el4:
            # 打印标题
            # input(ele1.text)
            print(ele1.text)
            count += 1;

        if count > 1:
            print("有数据")
            print(count)
        else:
            print("没数据")

if __name__ == '__main__':
    pytest.main()
