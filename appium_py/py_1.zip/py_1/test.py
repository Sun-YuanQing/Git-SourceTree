from appium import webdriver
from appium.webdriver import WebElement
from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.common.by import By
from appium.webdriver.extensions.android.nativekey import AndroidKey

desired_caps = {
    "platformName": "Android",
    "deviceName": "LMV500N01894ed0",
    "noReset": True
}

# 连接Appium Server，初始化自动化环境
driver = webdriver.Remote('http://127.0.0.1:4723/wd/hub', desired_caps)

# 设置缺省等待时间
driver.implicitly_wait(10)

# 根据id定位搜索位置框，点击
el2 = driver.find_element(AppiumBy.ID, "tv.danmaku.bili:id/expand_search")
el2.click()
# 根据id定位搜索输入框，点击
el3 = driver.find_element_by_accessibility_id("搜索查询")
el3.click()
el3.send_keys('白月黑羽')
print(el3.text)
# 输入回车键，确定搜索
driver.press_keycode(AndroidKey.ENTER)

# 选择（定位）所有视频标题
el4 = driver.find_elements(AppiumBy.CLASS_NAME, 'android.widget.TextView')
input(el4)
# print(el4)
elements = driver.element.find_elements_by_class_name("android.widget.TextView")
# input(elements)
# elements1 = elements[1].find_elements_by_class_name("android.view.ViewGroup")
# input(elements1)
input('**** Press to quit..121')
for ele1 in elements:
    # 打印标题
    input(ele1.text)
    print(ele1.text)

input('**** Press to quit..')
driver.quit()
